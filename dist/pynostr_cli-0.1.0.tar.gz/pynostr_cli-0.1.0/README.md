# pynostr-cli

Very early work in progress of a cli tool that will interface with the nostr protocol

Currently supported functionality:

- generates public and private key pair in either hex or pem format, with an option to output to a file

For more information, visit https://github.com/nostr-protocol/nostr

# Get started

`pip install pynostr-cli`